// Store Display App configuration
// Later, when n8n is ready, you can change dataSource to an API/webhook URL.
// The app can read either CSV or JSON arrays with similar product fields.
window.STORE_DISPLAY_CONFIG = {
  storeName: 'Test Store Icelandic',
  dataSource: './data/products.csv',
  currency: 'ISK',
  locale: 'is-IS',
  priceField: 'cost',
  imageField: 'img',
  barcodeField: 'barcodex'
};
