# Store Product Display App

A small static product-display app that can be deployed directly to Netlify from GitHub.

It currently reads products from `data/products.csv` and displays product cards with image, name, brand, price, weight, category, barcode/GTIN, and ingredients. It also supports product detail links like `#/product/7622210309648`.

## Files

```text
.
├── index.html
├── styles.css
├── app.js
├── config.js
├── netlify.toml
├── assets/
│   └── placeholder.svg
└── data/
    └── products.csv
```

## Deploy to GitHub + Netlify

1. Create a new GitHub repository.
2. Upload all files from this folder to the repository root.
3. In Netlify, create a new site from GitHub.
4. Choose the repository.
5. Use these build settings:
   - Build command: leave empty
   - Publish directory: `.`
6. Deploy.

## Updating products manually

Replace `data/products.csv` with a new CSV file using the same column names, then commit and push to GitHub. Netlify will redeploy the site.

The current app expects these useful columns when they are available:

- `name`
- `weight`
- `brand`
- `img`
- `cost`
- `ingredients`
- `categories`
- `store_categories`
- `barcodex`
- `status`

Extra columns are allowed and will not break the app.

## Later n8n connection

When n8n is ready, you have two simple options:

### Option A: n8n updates the CSV

Have n8n generate or replace `data/products.csv`, then redeploy the Netlify site from GitHub or through Netlify's deploy API.

### Option B: n8n/API returns data live

Change `config.js`:

```js
window.STORE_DISPLAY_CONFIG = {
  storeName: 'Test Store Icelandic',
  dataSource: 'https://your-api-or-n8n-endpoint.example/products',
  currency: 'ISK',
  locale: 'is-IS',
  priceField: 'cost',
  imageField: 'img',
  barcodeField: 'barcodex'
};
```

The app can read either:

- CSV text with the same headers as `data/products.csv`
- JSON array of products
- JSON object with a `products` array
- JSON object with a `data` array

If you use a live endpoint from another domain, the endpoint must allow browser requests with CORS headers.

## Local testing

Because the app uses `fetch()` to load `data/products.csv`, open it through a local web server instead of double-clicking `index.html`.

From the project folder:

```bash
python3 -m http.server 8080
```

Then open:

```text
http://localhost:8080
```
